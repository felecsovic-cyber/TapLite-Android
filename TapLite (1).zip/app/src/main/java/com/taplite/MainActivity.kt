package com.taplite

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        val title = TextView(this).apply {
            text = "TapLite — простой автокликер\n\n1. Разреши отображение поверх окон\n2. Включи TapLite в Спец. возможностях\n3. Вернись сюда и нажми «Запустить панель»\n\nПеретащи плавающую кнопку в точку нажатия. Нажми её для старта/остановки."
            textSize = 17f
        }
        val overlay = Button(this).apply {
            text = "Разрешить поверх окон"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val accessibility = Button(this).apply {
            text = "Открыть специальные возможности"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val launch = Button(this).apply {
            text = "Запустить панель"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                } else {
                    overlay.performClick()
                }
            }
        }
        layout.addView(title)
        layout.addView(overlay)
        layout.addView(accessibility)
        layout.addView(launch)
        setContentView(layout)
    }
}
