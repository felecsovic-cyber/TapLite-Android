package com.taplite

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var running = false
    private var interval = 500L
    private var targetX = 500f
    private var targetY = 800f
    private val handler = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            TapAccessibilityService.instance?.tap(targetX, targetY)
            handler.postDelayed(this, interval)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) createPanel()
        return START_STICKY
    }

    private fun createPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(0xEE222222.toInt())
        }
        val handle = Button(this).apply { text = "TapLite • перетащи"; textSize = 12f }
        val status = TextView(this).apply { text = "Интервал: 500 мс"; setTextColor(0xFFFFFFFF.toInt()) }
        val speed = SeekBar(this).apply {
            max = 19
            progress = 4
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    interval = (p + 1) * 100L
                    status.text = "Интервал: $interval мс"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        val start = Button(this).apply {
            text = "▶ Старт / Стоп"
            setOnClickListener {
                running = !running
                if (running) handler.post(loop) else handler.removeCallbacks(loop)
                text = if (running) "■ Остановить" else "▶ Старт"
            }
        }
        val close = Button(this).apply {
            text = "✕ Закрыть"
            setOnClickListener { running = false; handler.removeCallbacks(loop); stopSelf() }
        }
        root.addView(handle)
        root.addView(status)
        root.addView(speed)
        root.addView(start)
        root.addView(close)
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 150 }
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x = ox + (e.rawX - sx).toInt(); params.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, params); return true }
                }
                return false
            }
        })
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(loop)
        if (panel != null) { try { wm.removeView(panel) } catch (_: Exception) {}; panel = null }
        super.onDestroy()
    }
}
